# wsu
Displays ascii Wayne State University logo in CLI
